<?php
	session_start();
	require_once 'db_connector.php';
?>
Welcome